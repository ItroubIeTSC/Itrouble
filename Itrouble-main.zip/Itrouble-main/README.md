Select the checkboxes you like, the features are explained below
Enter a webhook in place of "Webhook Here" in Stealer (how to obtain webhook? Scroll down to how to obtain webhook)
Press on "CREATE STEALER FILES"
A file with random name shall be created. It will be saved to ".\output"
Upload the file to Discord or any other file hosting service (Link must be a direct download)
Copy the link to the file (Right click on the download icon/button & copy link)
Paste the link in place of "Random File Link Here" ──────────────────────────────────────────────────────────
OPTIONAL

Go to Advanced Options
Add any info you want the exe to have or copy from another file by using "COPY EXE INFO" button
an ICON (Either PNG or ICO format)
Click on "MESSAGEBOX" to add make a message box appear on start (Explaination ||On click scroll down to explanation||)
Go to File Stealer
Add a File Path in C# (Explained in the GUI)
Go to Stealer
Add Custom File (Must check "Custom File" checkbox), upload file & copy link & paste. As explained above, if your file format is not in the menu then put "|" after link and enter your file type extension ──────────────────────────────────────────────────────────
Go to Stealer
Click on "CREATE STEALER" & select path to save the stealer
Patiently wait for success or error Causes
Build Tools or .NET Framework Developer version not installed.
ICO isn't correctly converted...
If anything other issues, you may open a "Issue", but this being a disconntinued project. I won't do much other then assisting you.
Increase File Size using "File Pumper" (Optional & easy to use)
Checkbox Features

Crash PC (Broken)
Auto Remove EXE = Remove EXE after execution
Restart Discord = Restart any version of installed Discord
Camera Snapshot = Take a picture using webcam
Disable Antivirus + Run on Boot = Disable Windows Defender & run on startup of PC
Custom File = Run any type of file when the stealer is executed (Can be used to make it not so suspicious)
Obfuscate EXE = Make it harder to get source/webhook for the average user
MessageBox Usage

Enter Title
Enter Message
Select which buttons to be shown
Select icon to be displayed
Click on preview to check if everything is correct
Click on "OK" to save or X to exit
How to obtain webhook?

Create a server or use existing
Go to "Server Settings"
Go to "Integrations"
Click on "Create Webhook"
A webhook shall be created, click on Copy Webhook URL.
In case you want add picture, username, channel to be sent in...
